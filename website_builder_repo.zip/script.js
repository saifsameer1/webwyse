
document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;

    if(name && phone && email) {
        alert('Form submitted successfully!');
        // Here you would typically send the form data to the server
    } else {
        alert('Please fill out all fields.');
    }
});
